# Consultas - Aggregation Pipeline

## CONSULTA 1: Empleados con salario mayor al promedio de la empresa

### Método 1: Con $setWindowFields (MongoDB ≥5)

Explicación:
- Usamos $setWindowFields para calcular el promedio salarial de toda la empresa
- Este promedio se agrega como un campo a cada documento
- Luego filtramos con $match solo los empleados cuyo salario supera ese promedio
- Finalmente proyectamos los campos relevantes incluyendo la diferencia con el promedio

**Pipeline:**

db.empleados.aggregate([
  {
    // Calculamos el promedio de salarios de toda la empresa usando ventanas
    $setWindowFields: {
      output: {
        promedioEmpresa: { $avg: "$salario" }
      }
    }
  },
  {
    // Filtramos solo los empleados con salario mayor al promedio
    $match: {
      $expr: { $gt: ["$salario", "$promedioEmpresa"] }
    }
  },
  {
    // Proyectamos los campos relevantes
    $project: {
      nombre: 1,
      departamento_id: 1,
      salario: 1,
      promedioEmpresa: { $round: ["$promedioEmpresa", 2] },
      diferencia: { $round: [{ $subtract: ["$salario", "$promedioEmpresa"] }, 2] }
    }
  },
  {
    $sort: { salario: -1 }
  }
])

Resultado :
Promedio empresa: $1,016.67
Empleados encontrados: 3 (Frank, Carla, Ana)
Frank: $2000 (+$983.33)
Carla: $1500 (+$483.33)
Ana: $1200 (+$183.33)


### Método 2:Sin ventanas (usando $facet)

Explicación:
- Usamos $facet para ejecutar dos pipelines en paralelo
- Un pipeline calcula el promedio general
- Otro pipeline mantiene todos los empleados
- Luego combinamos ambos resultados y filtramos

**Pipeline:**
db.empleados.aggregate([
  {
    $facet: {
      // Pipeline para calcular el promedio
      promedio: [
        { $group: { _id: null, avg: { $avg: "$salario" } } }
      ],
      // Pipeline con todos los empleados
      empleados: []
    }
  },
  {
    // Extraemos el valor del promedio
    $project: {
      promedioEmpresa: { $arrayElemAt: ["$promedio.avg", 0] },
      empleados: 1
    }
  },
  {
    // Descomponemos el array de empleados
    $unwind: "$empleados"
  },
  {
    // Filtramos empleados con salario mayor al promedio
    $match: {
      $expr: { $gt: ["$empleados.salario", "$promedioEmpresa"] }
    }
  },
  {
    // Proyección final
    $project: {
      _id: "$empleados._id",
      nombre: "$empleados.nombre",
      departamento_id: "$empleados.departamento_id",
      salario: "$empleados.salario",
      promedioEmpresa: { $round: ["$promedioEmpresa", 2] },
      diferencia: { $round: [{ $subtract: ["$empleados.salario", "$promedioEmpresa"] }, 2] }
    }
  },
  {
    $sort: { salario: -1 }
  }
])


## CONSULTA 2:  Departamentos sin empleados asignados

Explicacion:
- Usamos $lookup para hacer un "join" entre departamentos y empleados
- El resultado del lookup es un array con los empleados de cada departamento
- Agregamos un campo que cuenta el tamaño de ese array
- Filtramos solo los departamentos donde el conteo es 0 (sin empleados)

**Pipeline:**
db.departamentos.aggregate([
  {
    // Hacemos un "join" con la colección empleados
    $lookup: {
      from: "empleados",
      localField: "_id",
      foreignField: "departamento_id",
      as: "empleados"
    }
  },
  {
    // Agregamos un campo con el conteo de empleados
    $addFields: {
      cantidadEmpleados: { $size: "$empleados" }
    }
  },
  {
    // Filtramos solo los departamentos sin empleados
    $match: {
      cantidadEmpleados: 0
    }
  },
  {
    // Proyectamos solo los campos relevantes
    $project: {
      _id: 1,
      nombre: 1,
      cantidadEmpleados: 1
    }
  }
])

Resultado :
Departamentos encontrados: 1
Logística (id: 4) - sin empleados


## CONSULTA 3: Empleado con salario más alto

Explicacion:
- Ordenamos todos los empleados por salario de forma descendente
- Tomamos solo el primer resultado usando $limit
- Este será el empleado con el salario más alto

**Pipeline:**
db.empleados.aggregate([
  {
    // Ordenamos por salario de mayor a menor
    $sort: { salario: -1 }
  },
  {
    // Tomamos solo el primer resultado
    $limit: 1
  },
  {
    // Proyección de campos
    $project: {
      _id: 1,
      nombre: 1,
      departamento_id: 1,
      salario: 1
    }
  }
])



## CONSULTA 4: Para cada empleado, mostrar el salario promedio de su departamento

Explicacion:
- Usamos $setWindowFields con partitionBy para agrupar por departamento
- Calculamos el promedio salarial dentro de cada partición (departamento)
- Cada empleado tendrá el promedio de su departamento como un campo adicional
- También calculamos la diferencia entre su salario y el promedio de su departamento

**Pipeline:**

db.empleados.aggregate([
  {
    // Calculamos el promedio salarial agrupado por departamento usando ventanas
    $setWindowFields: {
      partitionBy: "$departamento_id",
      output: {
        promedioDepartamento: { $avg: "$salario" }
      }
    }
  },
  {
    // Ordenamos por departamento y salario
    $sort: { departamento_id: 1, salario: -1 }
  },
  {
    // Proyectamos los campos relevantes
    $project: {
      _id: 1,
      nombre: 1,
      departamento_id: 1,
      salario: 1,
      promedioDepartamento: { $round: ["$promedioDepartamento", 2] },
      diferenciaConPromedio: { 
        $round: [{ $subtract: ["$salario", "$promedioDepartamento"] }, 2]
      }
    }
  }
])


## CONSULTA 5: Departamentos cuyo promedio salarial es mayor al promedio general

Explicacion:
- Usamos $facet para calcular dos cosas en paralelo:
   1. El promedio general de toda la empresa
   2. El promedio por cada departamento
- Luego comparamos ambos promedios
- Filtramos solo los departamentos cuyo promedio supera al promedio general
- Hacemos un lookup para obtener el nombre del departamento

**Pipeline:**
db.empleados.aggregate([
  {
    $facet: {
      // Calculamos el promedio general de toda la empresa
      promedioGeneral: [
        { $group: { _id: null, avg: { $avg: "$salario" } } }
      ],
      // Calculamos promedio por departamento
      porDepartamento: [
        {
          $group: {
            _id: "$departamento_id",
            promedioDepto: { $avg: "$salario" },
            cantidadEmpleados: { $sum: 1 }
          }
        }
      ]
    }
  },
  {
    // Extraemos los valores calculados
    $project: {
      promedioGeneral: { $arrayElemAt: ["$promedioGeneral.avg", 0] },
      porDepartamento: 1
    }
  },
  {
    // Descomponemos el array de departamentos
    $unwind: "$porDepartamento"
  },
  {
    // Filtramos departamentos con promedio mayor al general
    $match: {
      $expr: { 
        $gt: ["$porDepartamento.promedioDepto", "$promedioGeneral"] 
      }
    }
  },
  {
    // Join con departamentos para obtener el nombre
    $lookup: {
      from: "departamentos",
      localField: "porDepartamento._id",
      foreignField: "_id",
      as: "depto"
    }
  },
  {
    $unwind: "$depto"
  },
  {
    // Proyección final
    $project: {
      _id: "$porDepartamento._id",
      nombreDepartamento: "$depto.nombre",
      promedioDepartamento: { $round: ["$porDepartamento.promedioDepto", 2] },
      promedioGeneral: { $round: ["$promedioGeneral", 2] },
      cantidadEmpleados: "$porDepartamento.cantidadEmpleados",
      diferencia: { 
        $round: [{ $subtract: ["$porDepartamento.promedioDepto", "$promedioGeneral"] }, 2] 
      }
    }
  },
  {
    $sort: { promedioDepartamento: -1 }
  }
])


## CONSULTA 6: Sucursal "top" por mes (sucursal con mayor total de ventas)

Explicacion:
- Ordenamos las ventas por mes y total descendente
- Agrupamos por mes usando $group
- Usamos $first para tomar la primera sucursal de cada grupo (la de mayor venta)
- El resultado muestra para cada mes cuál sucursal tuvo las mayores ventas


**Pipeline:**

db.ventas.aggregate([
  {
    // Extraemos los campos del _id compuesto
    $addFields: {
      sucursal: "$_id.sucursal",
      mes: "$_id.mes"
    }
  },
  {
    // Ordenamos por mes y total descendente
    $sort: { mes: 1, total: -1 }
  },
  {
    // Agrupamos por mes y tomamos la sucursal con mayor venta
    $group: {
      _id: "$mes",
      sucursalTop: { $first: "$sucursal" },
      totalMaximo: { $first: "$total" }
    }
  },
  {
    // Ordenamos por mes
    $sort: { _id: 1 }
  },
  {
    // Proyección final
    $project: {
      _id: 0,
      mes: "$_id",
      sucursalTop: 1,
      totalMaximo: 1
    }
  }
])

Resultado :

2025-08: Guayaquil ($42,000)
2025-09: Quito ($39,000)

