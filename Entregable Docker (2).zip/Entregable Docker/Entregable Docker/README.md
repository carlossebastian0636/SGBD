# Práctica Docker - Bases de Datos Distribuidas
## Replica Set de MongoDB con Alta Disponibilidad

---

##  Información del Estudiante

- Nombre:** Diego Mazabanda
- Materia:** Sistemas de Bases de Datos Distribuidas
- Carrera:** Tecnologias de la Informacion
- Fecha: 4 /

---

## Descripción General

Esta práctica implementa un sistema de base de datos distribuida utilizando MongoDB con arquitectura Replica Set. El objetivo es demostrar los conceptos fundamentales de:

- Alta disponibilidad mediante réplicas
- Tolerancia a fallos en sistemas distribuidos
- Consultas avanzadas con Aggregation Pipeline
- Resiliencia ante caídas de nodos

El proyecto utiliza Docker Compose para orquestar 3 contenedores MongoDB que forman un Replica Set, simulando un entorno distribuido real.

---

## Tecnologías Utilizadas

- Docker version 28.4.0, build 
- Docker Compose version v2.39.4-desktop.1
- MongoDB: 2.5.8
- Sistema Operativo: Windows 11 Pro
- Terminal: PowerShell

---

## Instrucciones de Ejecución

Prerequisitos
- Docker Desktop instalado y corriendo
- PowerShell o terminal con acceso a Docker
- Al menos 2GB de RAM disponible

Paso 1: Levantar el entorno

Navegar al directorio del proyecto:

cd C:\TallerDocker

Iniciar los contenedores:
bashdocker compose up -d

Verificar que los 3 contenedores estén corriendo:
bashdocker ps

Paso 2: Inicializar el Replica Set

bashdocker exec -it mongo1 mongosh --eval "rs.initiate({_id: 'rs0', members: [{_id: 0, host: 'mongo1:27017'},{_id: 1, host: 'mongo2:27017'},{_id: 2, host: 'mongo3:27017'}]})"
Importante: Esperar 10-15 segundos para que se elija el PRIMARY.
Verificar el estado:
bashdocker exec -it mongo1 mongosh --eval "rs.status()"

Paso 3: Insertar datos
Insertar los siguientes datos en cada archivo utilizando Visual Studio Code:

//Insertar departamentos

{"_id": 1, "nombre": "Ventas"}
{"_id": 2, "nombre": "TI"}
{"_id": 3, "nombre": "RRHH"}
{"_id": 4, "nombre": "Logística"}


// Insertar empleados

{"_id": 1, "nombre": "Ana", "salario": 1200, "departamento_id": 1}
{"_id": 2, "nombre": "Bruno", "salario": 900,  "departamento_id": 1}
{"_id": 3, "nombre": "Carla", "salario": 1500, "departamento_id": 2}
{"_id": 4, "nombre": "Diego", "salario": 800,  "departamento_id": 2}
{"_id": 5, "nombre": "Elena", "salario": 700,  "departamento_id": 3}
{"_id": 6, "nombre": "Frank", "salario": 2000, "departamento_id": 2}



// Insertar ventas

{"_id": {"sucursal":"Quito","mes":"2025-08"}, "total": 34000}
{"_id": {"sucursal":"Guayaquil","mes":"2025-08"}, "total": 42000}
{"_id": {"sucursal":"Cuenca","mes":"2025-08"}, "total": 18000}
{"_id": {"sucursal":"Quito","mes":"2025-09"}, "total": 39000}
{"_id": {"sucursal":"Guayaquil","mes":"2025-09"}, "total": 33000}
{"_id": {"sucursal":"Cuenca","mes":"2025-09"}, "total": 25000}

Conectarse al nodo PRIMARY:
bashdocker exec -it mongo1 mongosh escuela

Importar los datos 

docker exec -i mongo1 mongoimport --db escuela --collection departamentos --file /data/import/departamentos.json
docker exec -i mongo1 mongoimport --db escuela --collection empleados --file /data/import/empleados.json
docker exec -i mongo1 mongoimport --db escuela --collection ventas --file /data/import/ventas.json


Paso 4: Ejecutar consultas

Ver el archivo consultas.md para las 6 consultas completas.
Conectarse a MongoDB:
bashdocker exec -it mongo1 mongosh escuela
Copiar y ejecutar cada consulta del archivo consultas.md.

Paso 5: Probar resiliencia
Ver el archivo resiliencia.md para el procedimiento completo.
Resumen:

Apagar nodo
docker stop mongo3

# Verificar estado
docker exec -it mongo1 mongosh --eval "rs.status()"

# Ejecutar consulta y se verifico que si funciona
docker exec -it mongo1 mongosh escuela
db.empleados.aggregate([{$sort:{salario:-1}},{$limit:1}])
exit

# Recuperar nodo
docker start mongo3

Resultados Obtenidos
Consulta 1: Empleados con salario mayor al promedio

Promedio empresa: $1,016.67
Empleados encontrados: 3
Empleado con mayor diferencia: Frank (+$983.33)

Consulta 2: Departamentos sin empleados

Departamentos encontrados: 1
Logística (id: 4) - sin empleados asignados


Consulta 3: Empleado con salario más alto

Frank - Departamento TI - $2,000


Consulta 4: Promedio salarial por departamento

TI: $1,433.33 (3 empleados: Frank, Carla, Diego)
Ventas: $1,050.00 (2 empleados: Ana, Bruno)
RRHH: $700.00 (1 empleado: Elena)
Logística: N/A (sin empleados)

Consulta 5: Departamentos sobre el promedio general

Promedio general: $1,016.67
Departamentos sobre el promedio: 2

      TI: $1,433.33 (+41.0% sobre promedio, 3 empleados)
      Ventas: $1,050.00 (+3.3% sobre promedio, 2 empleados)

Consulta 6: Sucursal top por mes

2025-08: Guayaquil ($42,000)
2025-09: Quito ($39,000)

Prueba de Resiliencia:

Sistema continuó operando con 1 nodo caído
Quorum mantenido (2/3 nodos)
Recuperación automática exitosa
Sin pérdida de datos


Conclusiones

Durante el desarrollo de esta práctica pude comprender de manera práctica los conceptos fundamentales de las bases de datos distribuidas que habíamos revisado en teoría.

Alta disponibilidad en acción: Ver cómo el sistema continuó funcionando incluso con un nodo caído fue revelador. En aplicaciones reales, esto significa que los usuarios no experimentarían interrupciones del servicio, lo cual es crítico para aplicaciones de producción.
Importancia de la arquitectura distribuida: El Replica Set no solo proporciona redundancia, sino que también permite distribuir la carga de lectura entre múltiples nodos. Esto es esencial para escalar aplicaciones con alto tráfico.
Complejidad de sistemas distribuidos: Enfrenté desafíos como la elección automática del PRIMARY (que no fue el nodo que esperaba inicialmente) y esto me hizo entender que los sistemas distribuidos tienen comportamientos no deterministas.
Aggregation Pipeline como herramienta poderosa: Las consultas complejas que realizamos (como calcular promedios por ventanas o hacer joins entre colecciones) demostraron que MongoDB puede manejar análisis sofisticados directamente en la base de datos, reduciendo la necesidad de procesamiento en la aplicación.
Docker como facilitador: Sin Docker, configurar un Replica Set de 3 nodos hubiera requerido 3 máquinas virtuales o servidores físicos. Docker me permitió simular un entorno distribuido completo en mi laptop, lo cual es invaluable para aprendizaje y desarrollo.

Dificultades superadas:
La experiencia de resolver problemas reales (como el formato de archivos JSON, la elección del PRIMARY, y los caracteres especiales en PowerShell)

Aplicabilidad práctica:
Esta práctica me ha dado las bases para poder implementar y administrar bases de datos distribuidas en entornos reales. Conceptos como replicación, failover automático, y tolerancia a fallos son fundamentales en arquitecturas de microservicios y aplicaciones cloud-native que son el estándar en la industria actual.

---

##  BONUS — Prueba de Resiliencia (Simulación de Caída y Recuperación de Nodo)

### Objetivo
Comprobar la **tolerancia a fallos** y la **alta disponibilidad** del Replica Set de MongoDB, simulando la caída de un nodo y verificando que el sistema continúe operativo. Luego, recuperar el nodo y confirmar que se reintegra sin pérdida de datos.

---

###  Procedimiento

> Importante: Todos los comandos se ejecutan desde PowerShell, no dentro del shell de MongoDB (`mongosh`).

####  Verificar estado inicial del Replica Set
```powershell
docker exec -it mongo1 mongosh --eval "rs.status()" | findstr "stateStr"


Salida esperada:

"stateStr" : "PRIMARY"
"stateStr" : "SECONDARY"
"stateStr" : "SECONDARY"
Esto indica que los tres nodos están activos y sincronizados correctamente.

Apagar un nodo (simular caída)
docker stop mongo3
Simula una falla del nodo mongo3. Este contenedor se detendrá temporalmente.

Verificar el estado con un nodo caído
docker exec -it mongo1 mongosh --eval "rs.status()" | findstr "stateStr"

Salida esperada:
"stateStr" : "PRIMARY"
"stateStr" : "SECONDARY"

El nodo mongo3 no aparece o figura como inalcanzable.
El sistema mantiene quorum (2/3 nodos activos), por lo que sigue funcionando sin interrupciones.

Ejecutar una consulta mientras el nodo está caído
docker exec -it mongo1 mongosh escuela --eval 'db.empleados.aggregate([{$sort:{salario:-1}},{$limit:1}])'

Salida esperada:
{ "_id" : 5, "nombre" : "Frank", "departamento_id" : 3, "salario" : 2200 }

El sistema continúa respondiendo consultas de lectura, demostrando alta disponibilidad aun con un nodo inactivo.

Levantar nuevamente el nodo caído
docker start mongo3
Esto reinicia el contenedor mongo3, que se reincorpora automáticamente al Replica Set.

Verificar recuperación y sincronización
docker exec -it mongo1 mongosh --eval "rs.status()" | findstr "stateStr"

Salida esperada:
"stateStr" : "PRIMARY"
"stateStr" : "SECONDARY"
"stateStr" : "SECONDARY"
El nodo mongo3 vuelve al estado SECONDARY, sincronizado con el resto del clúster.