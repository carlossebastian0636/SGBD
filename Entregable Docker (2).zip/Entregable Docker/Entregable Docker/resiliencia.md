### Prueba de Resiliencia del Replica Set #####

Procedimiento

1. Estado inicial
- Replica Set con 3 nodos funcionando
- mongo1: PRIMARY
- mongo2: SECONDARY
- mongo3: SECONDARY

Comando para verificar:
docker exec -it mongo1 mongosh --eval "rs.status()" | findstr "stateStr"

2. Caída del nodo mongo3
   Comando ejecutado:
   docker stop 

3. Observaciones con el nodo caído
   ¿Qué ocurrió?

- El Replica Set continuó operando normalmente
- mongo1 (PRIMARY) siguió aceptando lecturas y escrituras
- mongo2 (SECONDARY) siguió replicando datos
- El sistema mantuvo el quorum (2 de 3 nodos activos)

Estado del cluster:

- Nodos activos: 2/3
- PRIMARY: mongo1 (sin cambios)
- SECONDARY: mongo2 (sin cambios)
- mongo3: No alcanzable

Consultas ejecutadas:

- Las consultas funcionaron sin ningún problema
- No hubo pérdida de datos
- No hubo degradación del servicio

4. Recuperación del nodo
Comando ejecutado:
docker start mongo3

¿Qué ocurrió?

- mongo3 se reconectó al Replica Set automáticamente
- Se sincronizó con el PRIMARY para obtener datos que pudo haber perdido
- Volvió a su estado SECONDARY
- El cluster volvió a tener 3 nodos completamente funcionales


### Ventajas de Replica Set en Bases de Datos Distribuidas:

- Alta disponibilidad: El sistema siguió funcionando con solo 2 de 3 nodos
- Sin pérdida de datos: Todas las escrituras se mantuvieron
- Recuperación automática: mongo3 se reincorporó sin intervención manual
- Tolerancia a fallos: El sistema puede soportar la caída de N/2 - 1 nodos

### ¿Por qué funcionó con 2 nodos?

- MongoDB usa votación por mayoría para elegir PRIMARY
- Con 3 nodos, se necesitan 2 votos (mayoría)
- 2 nodos activos = quorum alcanzado
- El sistema continúa operando

### ¿Qué pasaría si cayeran 2 nodos?

Solo quedaría 1 nodo activo
No hay quorum (necesita 2 de 3)
El nodo PRIMARY se volvería SECONDARY
No se aceptarían escrituras (solo lecturas si se configura)
El cluster entraría en modo "solo lectura" hasta recuperar otro nodo

##### Versiones de Software Utilizadas
- Docker version 28.4.0, build 
- Docker Compose version v2.39.4-desktop.1
- MongoDB: 2.5.8
- Sistema Operativo: Windows 11 Pro
- Terminal: PowerShell

##### Dificultades Encontradas y Soluciones

1. mongo1 no era el PRIMARY inicial

Problema:
Al inicializar el Replica Set con `rs.initiate()`, MongoDB eligió automáticamente a "mongo2" como PRIMARY en lugar de mongo1. Esto causaba errores al intentar importar datos en mongo1, ya que solo el nodo PRIMARY puede aceptar escrituras.

Error obtenido:
Failed: (NotWritablePrimary) not primary
0 document(s) imported successfully

Causa:
MongoDB realiza una elección democrática automática al inicializar el Replica Set. El PRIMARY se elige basándose en factores como conectividad, latencia y prioridad. No necesariamente será el primer nodo de la lista.

**Solución aplicada:**
- Nos conectamos al nodo PRIMARY actual (mongo2):
   docker exec -it mongo2 mongosh

- Forzamos al PRIMARY actual a renunciar usando:
 rs.stepDown()

- Esperamos 10-15 segundos para que se realizara una nueva elección
- Verificamos el nuevo estado:
docker exec -it mongo1 mongosh --eval "rs.status()"

- Confirmamos que mongo1 ahora era PRIMARY y procedimos con la importación de datos

En un Replica Set real, el PRIMARY puede cambiar en cualquier momento (failover automático). Las aplicaciones deben estar preparadas para conectarse al PRIMARY actual, no asumir que siempre será el mismo nodo.